# AI-Powered Recruitment Recommendation System

A working starter web application for the hackathon project **Recruitment Recommendation**. It compares candidate resumes with a recruiter-provided job description, identifies listed skills, calculates an explainable similarity score, and ranks candidates.

## Features

- Responsive recruiter dashboard
- Job title and job description form
- Multiple PDF resume uploads (up to 20 resumes per analysis; 10 MB total request limit)
- Text extraction from text-based PDFs with PyMuPDF
- Skill identification from a configurable vocabulary
- TF-IDF cosine similarity plus skill-overlap scoring
- Ranked candidate results, matched skills, and missing listed skills
- SQLite storage for job descriptions and candidate analysis records
- Candidate search, detail view, and delete action
- Input validation and basic upload error handling
- No paid AI API key required

## Important limitations

- This is a working **prototype**, not a production hiring platform.
- It supports text-based PDFs. Scanned/image-only PDFs need OCR, which is not included.
- The skill vocabulary is a starter list in `app.py`; edit `SKILL_TERMS` to add domain-specific skills.
- The score is a similarity indicator, not a prediction of job performance. It should not be the sole basis for hiring decisions. Recruiters must review candidates fairly and independently.
- The app stores extracted resume text and candidate data in a local SQLite database. Use fictional or consented test data. Do not deploy publicly with real personal data without adding authentication, authorization, retention controls, and a production security review.
- For public deployment, set a strong `SECRET_KEY`, disable debug mode, and use a production WSGI server.

## Run locally

Requires Python 3.10 or newer.

1. Unzip the project.
2. Open a terminal in the `recruitment_recommendation_system` folder.
3. Create and activate a virtual environment (recommended):

   **Windows**
   ```bash
   python -m venv .venv
   .venv\Scripts\activate
   ```

   **macOS/Linux**
   ```bash
   python3 -m venv .venv
   source .venv/bin/activate
   ```

4. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```

5. Start the application:
   ```bash
   python app.py
   ```

6. Open `http://127.0.0.1:5000` in your browser.

The SQLite database (`recruitment.db`) is created automatically at first run. Uploaded PDFs are processed and removed after analysis; the database retains extracted text and analysis data.

## Test workflow

1. Select **Analyze Resumes**.
2. Enter a job title, e.g. `Junior Python Developer`.
3. Enter a job description containing requirements such as `Python, SQL, Flask, REST API, Git`.
4. Upload one or more text-based PDF resumes.
5. Review ranked results and open a candidate's details.
6. Open **Candidates** to search stored results or delete a record.

## GitHub upload

1. Create a new repository on GitHub named `recruitment-recommendation-system`.
2. Upload the files and folders from this project. Do not upload `.venv`, private resumes, or a production database.
3. Keep the repository public only if your organizer requires a public link and the repository contains no personal data or secrets.
4. Copy the repository URL, e.g. `https://github.com/YOUR-USERNAME/recruitment-recommendation-system`.

## Project structure

```text
recruitment_recommendation_system/
├── app.py
├── requirements.txt
├── README.md
├── .gitignore
├── templates/
│   ├── base.html
│   ├── index.html
│   ├── analyze.html
│   ├── results.html
│   ├── candidates.html
│   ├── candidate.html
│   └── 404.html
├── static/
│   └── style.css
└── uploads/
    └── .gitkeep
```
