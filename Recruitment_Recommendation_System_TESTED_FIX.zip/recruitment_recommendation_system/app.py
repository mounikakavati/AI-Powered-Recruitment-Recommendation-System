import os
import re
import sqlite3
import uuid
from datetime import datetime
from collections import Counter
from math import log, sqrt

import fitz  # PyMuPDF
from flask import Flask, render_template, request, redirect, url_for, flash, abort
from werkzeug.utils import secure_filename

BASE_DIR = os.path.abspath(os.path.dirname(__file__))
DATABASE = os.path.join(BASE_DIR, "recruitment.db")
UPLOAD_FOLDER = os.path.join(BASE_DIR, "uploads")
ALLOWED_EXTENSIONS = {"pdf"}
MAX_CONTENT_LENGTH = 10 * 1024 * 1024  # 10 MB per request

app = Flask(__name__)
app.config["SECRET_KEY"] = os.environ.get("SECRET_KEY", "change-this-for-production")
app.config["UPLOAD_FOLDER"] = UPLOAD_FOLDER
app.config["MAX_CONTENT_LENGTH"] = MAX_CONTENT_LENGTH
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

# Transparent starter vocabulary. This is a decision-support aid, not a hiring decision.
SKILL_TERMS = [
    "python", "java", "javascript", "typescript", "c", "c++", "c#", "sql",
    "html", "css", "react", "angular", "vue", "node.js", "nodejs", "flask",
    "django", "spring boot", "express", "mongodb", "mysql", "postgresql",
    "sqlite", "git", "github", "docker", "kubernetes", "aws", "azure", "gcp",
    "machine learning", "deep learning", "artificial intelligence", "nlp",
    "data analysis", "data visualization", "pandas", "numpy", "scikit-learn",
    "tensorflow", "pytorch", "power bi", "tableau", "excel", "linux",
    "cybersecurity", "network security", "cryptography", "rest api", "api",
    "android", "ios", "kotlin", "swift", "mern", "full stack", "communication",
    "problem solving", "testing", "agile", "oop", "data structures",
    "algorithms", "cloud computing", "blockchain", "java full stack",
    "project management", "leadership", "salesforce", "php", "laravel",
    "ruby", "rails", "go", "rust", "microservices", " CI/CD".strip().lower()
]
STOP_WORDS = {
    "a","an","the","and","or","but","if","then","than","of","to","in","on","at",
    "for","from","with","by","as","is","are","was","were","be","been","being",
    "this","that","these","those","it","its","we","you","your","our","their",
    "will","can","may","must","should","have","has","had","do","does","did",
    "not","no","yes","about","into","over","under","up","down","such","using",
    "use","used","work","working","role","job","candidate","required","preferred",
    "experience","years","year","skills","skill","knowledge","ability","strong"
}

def get_db():
    conn = sqlite3.connect(DATABASE)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    with get_db() as conn:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS candidates (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                candidate_name TEXT NOT NULL,
                filename TEXT NOT NULL,
                extracted_text TEXT NOT NULL,
                detected_skills TEXT NOT NULL,
                match_score REAL NOT NULL DEFAULT 0,
                matched_skills TEXT NOT NULL DEFAULT '',
                missing_skills TEXT NOT NULL DEFAULT '',
                job_title TEXT NOT NULL,
                job_description TEXT NOT NULL,
                created_at TEXT NOT NULL
            )
        """)
        conn.execute("""
            CREATE TABLE IF NOT EXISTS jobs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                job_title TEXT NOT NULL,
                job_description TEXT NOT NULL,
                created_at TEXT NOT NULL
            )
        """)

def allowed_file(filename):
    return "." in filename and filename.rsplit(".", 1)[1].lower() in ALLOWED_EXTENSIONS

def extract_pdf_text(path):
    try:
        with fitz.open(path) as doc:
            text = "\n".join(page.get_text("text") for page in doc)
        return "\n".join(re.sub(r"[ \t]+", " ", line).strip() for line in text.splitlines() if line.strip()).strip()
    except Exception as exc:
        raise ValueError("The PDF could not be read. Please upload a valid, text-based PDF.") from exc

def detect_skills(text):
    lowered = text.lower()
    found = []
    for skill in SKILL_TERMS:
        # Avoid partial word matches for short terms; allow punctuation in skill names.
        pattern = r"(?<![a-z0-9])" + re.escape(skill) + r"(?![a-z0-9])"
        if re.search(pattern, lowered):
            found.append(skill)
    return sorted(set(found))

def tokenize(text):
    tokens = re.findall(r"[a-zA-Z][a-zA-Z0-9+#.]*", text.lower())
    return [t for t in tokens if len(t) > 1 and t not in STOP_WORDS]

def cosine_tfidf(text_a, text_b):
    """Small dependency-light TF-IDF cosine similarity for one document pair."""
    docs = [tokenize(text_a), tokenize(text_b)]
    if not docs[0] or not docs[1]:
        return 0.0
    counts = [Counter(d) for d in docs]
    vocab = set(counts[0]) | set(counts[1])
    vecs = []
    for count in counts:
        vec = {}
        for term, tf in count.items():
            df = sum(1 for doc_count in counts if doc_count.get(term, 0) > 0)
            idf = log((1 + len(docs)) / (1 + df)) + 1
            vec[term] = (1 + log(tf)) * idf
        vecs.append(vec)
    dot = sum(value * vecs[1].get(term, 0.0) for term, value in vecs[0].items())
    norm_a = sqrt(sum(v*v for v in vecs[0].values()))
    norm_b = sqrt(sum(v*v for v in vecs[1].values()))
    return dot / (norm_a * norm_b) if norm_a and norm_b else 0.0

def score_candidate(job_description, resume_text):
    job_skills = set(detect_skills(job_description))
    candidate_skills = set(detect_skills(resume_text))
    matched = sorted(job_skills & candidate_skills)
    missing = sorted(job_skills - candidate_skills)
    skill_score = len(matched) / len(job_skills) if job_skills else 0.0
    similarity = cosine_tfidf(job_description, resume_text)
    # Give skills a strong weight while still considering general textual relevance.
    score = (0.75 * skill_score + 0.25 * similarity) * 100
    return round(min(100.0, max(0.0, score)), 1), sorted(candidate_skills), matched, missing

def candidate_name_from_text(text, filename):
    # Prefer an explicit name-like first line if available; otherwise use file name.
    first_lines = [line.strip() for line in text.splitlines() if line.strip()]
    if first_lines:
        first = re.sub(r"\s+", " ", first_lines[0]).strip()
        if 2 <= len(first) <= 60 and len(first.split()) <= 6 and not re.search(r"[@\d:/]", first):
            if sum(ch.isalpha() for ch in first) >= 3:
                return first
    stem = os.path.splitext(secure_filename(filename))[0].replace("_", " ").replace("-", " ").strip()
    return stem.title() or "Unknown Candidate"

@app.route("/")
def index():
    with get_db() as conn:
        total_candidates = conn.execute("SELECT COUNT(*) FROM candidates").fetchone()[0]
        total_jobs = conn.execute("SELECT COUNT(*) FROM jobs").fetchone()[0]
        recent = conn.execute("SELECT * FROM candidates ORDER BY match_score DESC, created_at DESC LIMIT 5").fetchall()
    return render_template("index.html", total_candidates=total_candidates, total_jobs=total_jobs, recent=recent)

@app.route("/analyze", methods=["GET", "POST"])
def analyze():
    if request.method == "GET":
        return render_template("analyze.html")
    job_title = request.form.get("job_title", "").strip()
    job_description = request.form.get("job_description", "").strip()
    files = request.files.getlist("resumes")
    if not job_title or not job_description:
        flash("Enter a job title and job description.", "error")
        return redirect(url_for("analyze"))
    uploads = [f for f in files if f and f.filename]
    if not uploads:
        flash("Choose at least one PDF resume.", "error")
        return redirect(url_for("analyze"))
    if len(uploads) > 20:
        flash("Please upload no more than 20 resumes at a time.", "error")
        return redirect(url_for("analyze"))
    if len(job_description) > 20000:
        flash("The job description is too long. Please keep it under 20,000 characters.", "error")
        return redirect(url_for("analyze"))

    now = datetime.utcnow().isoformat(timespec="seconds") + "Z"
    results = []
    with get_db() as conn:
        conn.execute("INSERT INTO jobs (job_title, job_description, created_at) VALUES (?, ?, ?)",
                     (job_title, job_description, now))
        for uploaded in uploads:
            if not allowed_file(uploaded.filename):
                flash(f"Skipped {secure_filename(uploaded.filename)}: only PDF files are allowed.", "error")
                continue
            safe_name = secure_filename(uploaded.filename) or "resume.pdf"
            stored_name = f"{uuid.uuid4().hex}_{safe_name}"
            path = os.path.join(app.config["UPLOAD_FOLDER"], stored_name)
            try:
                uploaded.save(path)
                if os.path.getsize(path) == 0:
                    raise ValueError("This file is empty.")
                if os.path.getsize(path) > 10 * 1024 * 1024:
                    raise ValueError("This file is larger than 10 MB.")
                text = extract_pdf_text(path)
                if len(text) < 20:
                    raise ValueError("No readable text found. Scanned/image-only PDFs are not supported in this version.")
                score, skills, matched, missing = score_candidate(job_description, text)
                name = candidate_name_from_text(text, safe_name)
                cur = conn.execute("""
                    INSERT INTO candidates
                    (candidate_name, filename, extracted_text, detected_skills, match_score,
                     matched_skills, missing_skills, job_title, job_description, created_at)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """, (name, safe_name, text[:100000], ", ".join(skills), score,
                      ", ".join(matched), ", ".join(missing), job_title, job_description, now))
                results.append(cur.lastrowid)
            except ValueError as exc:
                flash(f"{safe_name}: {exc}", "error")
            except Exception:
                flash(f"{safe_name}: processing failed. Please try a different PDF.", "error")
            finally:
                # Keep only extracted data in the database; remove uploaded files after processing.
                if os.path.exists(path):
                    try:
                        os.remove(path)
                    except OSError:
                        pass
    if not results:
        flash("No resumes were analyzed. Check the error messages and try again.", "error")
        return redirect(url_for("analyze"))
    return redirect(url_for("results", ids=",".join(map(str, results))))

@app.route("/results")
def results():
    ids_raw = request.args.get("ids", "")
    candidates = []
    if ids_raw:
        ids = []
        for item in ids_raw.split(",")[:20]:
            if item.isdigit():
                ids.append(int(item))
        if ids:
            placeholders = ",".join("?" for _ in ids)
            with get_db() as conn:
                candidates = conn.execute(
                    f"SELECT * FROM candidates WHERE id IN ({placeholders}) ORDER BY match_score DESC",
                    ids
                ).fetchall()
    return render_template("results.html", candidates=candidates)

@app.route("/candidates")
def candidates():
    query = request.args.get("q", "").strip()
    with get_db() as conn:
        if query:
            like = f"%{query}%"
            rows = conn.execute("""
                SELECT * FROM candidates
                WHERE candidate_name LIKE ? OR job_title LIKE ? OR detected_skills LIKE ?
                ORDER BY match_score DESC, created_at DESC
            """, (like, like, like)).fetchall()
        else:
            rows = conn.execute("SELECT * FROM candidates ORDER BY match_score DESC, created_at DESC").fetchall()
    return render_template("candidates.html", candidates=rows, query=query)

@app.route("/candidate/<int:candidate_id>")
def candidate_detail(candidate_id):
    with get_db() as conn:
        candidate = conn.execute("SELECT * FROM candidates WHERE id = ?", (candidate_id,)).fetchone()
    if not candidate:
        abort(404)
    return render_template("candidate.html", candidate=candidate)

@app.route("/candidate/<int:candidate_id>/delete", methods=["POST"])
def delete_candidate(candidate_id):
    with get_db() as conn:
        conn.execute("DELETE FROM candidates WHERE id = ?", (candidate_id,))
    flash("Candidate record deleted.", "success")
    return redirect(url_for("candidates"))

@app.route("/health")
def health():
    return {"status": "ok", "application": "Recruitment Recommendation System"}

@app.errorhandler(413)
def too_large(_error):
    flash("Upload too large. Keep the total request under 10 MB.", "error")
    return redirect(url_for("analyze"))

@app.errorhandler(404)
def not_found(_error):
    return render_template("404.html"), 404

init_db()

if __name__ == "__main__":
    app.run(debug=False, host="0.0.0.0", port=int(os.environ.get("PORT", "5000")))
